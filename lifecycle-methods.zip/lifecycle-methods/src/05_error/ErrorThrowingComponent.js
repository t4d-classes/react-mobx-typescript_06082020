export const ErrorThrowingComponent = () => {
  throw new Error('Error Thrown!');
};
